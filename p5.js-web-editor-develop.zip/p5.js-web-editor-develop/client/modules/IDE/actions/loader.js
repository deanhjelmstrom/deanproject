import * as ActionTypes from '../../../constants';

export function startLoader() {
  return { type: ActionTypes.START_LOADING };
}

export function stopLoader() {
  return { type: ActionTypes.STOP_LOADING };
}
