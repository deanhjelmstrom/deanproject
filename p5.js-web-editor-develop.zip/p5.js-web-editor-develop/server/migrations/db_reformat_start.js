require('@babel/register');
require('@babel/polyfill');
require('./db_reformat');
