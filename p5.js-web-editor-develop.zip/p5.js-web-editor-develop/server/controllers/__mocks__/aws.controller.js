export const getObjectKey = jest.mock();
export const deleteObjectsFromS3 = jest.fn();
export const signS3 = jest.fn();
export const copyObjectInS3RequestHandler = jest.fn();
export const listObjectsInS3ForUser = jest.fn();
